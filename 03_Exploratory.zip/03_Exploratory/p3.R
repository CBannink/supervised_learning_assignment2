library(tidyverse)
library(magrittr)
library(mice)
library(DAAG)
head(boys)
tail(boys)
!is.unsorted(boys$age)
summary(boys)
hist<- ggplot(boys,aes(x = age))+geom_histogram()
hist
bar <- ggplot(boys,aes(x=gen))+geom_bar()
bar
md.pattern(boys)
na <- boys %>%
  mutate(gen_na = is.na(gen),
         phb_na = is.na(phb),
         tv_na  = is.na(tv))
na %>% group_by(gen_na)%>%
  summarize(age = mean(age))
na %>% group_by(phb_na)%>%
  summarize(age = mean(age))
na %>% group_by(tv_na)%>%
  summarize(age = mean(age))
hist_facet <- ggplot(na, aes(x = age))+
  geom_histogram()+
  facet_wrap(~gen_na)
hist_facet
scatter<- ggplot(na,aes(x=age, y=bmi, color = gen_na))+geom_point()
scatter
box<-ggplot(boys,aes(x=reg, y=age))+geom_boxplot()
box
dens <- ggplot(boys,aes(x=age,fill = gen))+geom_density()
dens
boys%>%mutate(age_cut = cut(age,min(age):max(age)))%>%
  mutate(height_dev = hgt-mean(hgt, na.rm = TRUE))%>%
  group_by(age_cut)%>%
  summarize(height_dev = mean(height_dev, na.rm=TRUE))%>%
  ggplot(aes(x=height_dev,y=age_cut))+
  geom_bar(stat='identity')


elastic <- bind_rows("Elastic1" = elastic1,"Elastic2" = elastic2, .id = "Set")

point <-ggplot(elastic, aes(x = stretch, y = distance, col = Set)) +
  geom_point()
point
smooth <-  ggplot(elastic, aes(x = stretch, y = distance, col = Set)) +
  geom_point() +
  geom_smooth(method = "lm")
smooth

lm1 <- lm(distance ~ stretch, elastic1)
lm1%>% predict(se.fit=TRUE)
lm1 %>% summary()
lm1 %>% plot(which = 5)
pred <- predict(lm1, newdata = elastic2)

